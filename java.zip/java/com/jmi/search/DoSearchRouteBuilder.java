package com.jmi.search;

import com.jmi.common.dto.AddressSearchResponseDTO;
import com.jmi.search.dto.SearchRequestDTO;
import com.jmi.search.processors.SearchRequestProcessor;
import com.jmi.common.SearchResponseProcessor;
import com.jmi.common.util.CommonUtil;
import gw.api.ig.failure.FailureConfiguration;
import gw.impl.ig.failure.DefaultFailureConfiguration;
import gw.impl.ig.route.GwRouteBuilder;
import jakarta.inject.Named;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;

@Named
public class DoSearchRouteBuilder extends GwRouteBuilder {

    @Override
    public void configure() throws Exception {
        rest().path(CommonUtil.SEARCH_ADDRESS_PATH_ID)
                .post("/doSearch")
                .description("Address Search")
                .bindingMode(RestBindingMode.json)
                .consumes("application/json")
                .type(SearchRequestDTO.class)
                .produces("application/json")
                .outType(AddressSearchResponseDTO.class)
                .to(CommonUtil.SEARCH_ROUTE_DIRECT);
        from(CommonUtil.SEARCH_ROUTE_DIRECT)
                .routeId(CommonUtil.SEARCHADDR_ROUTE_ID)
                .log("Started Processing for Search Address")
                .process(new SearchRequestProcessor())
                .marshal()
                .json(JsonLibrary.Jackson, SearchRequestDTO.class)
                .log("Request Post Marshalling")
                .to("{{INTEGRATION.ENDPOINT.REMOTEHOST}}"+"{{INTEGRATION.ENDPOINT.REMOTEURI}}"+"{{INTEGRATION.ENDPOINT.SEARCHURL}}")
                .log("ENDPOINT"+"{{INTEGRATION.ENDPOINT.REMOTEHOST}}"+"{{INTEGRATION.ENDPOINT.REMOTEURI}}"+"{{INTEGRATION.ENDPOINT.SEARCHURL}}")
                .process(new SearchResponseProcessor())
                .log("END")
                .end();

    }

    @Override
    public FailureConfiguration<?> createFailureConfiguration() {
        return new DefaultFailureConfiguration();
    }
}

package com.jmi.search.processors;

import com.google.gson.Gson;
import com.jmi.search.dto.SearchRequestDTO;
import gw.api.ig.GwUtilities;
import gw.api.ig.logging.GwLogger;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * This class is used to process the request for Address Search
 * Transforms the SearchRequest object into JsonString
 */
public class SearchRequestProcessor implements Processor {
    @Override
    public void process(Exchange exchange) throws Exception {
        GwUtilities gwUtilities = GwUtilities.get(exchange.getContext());
        GwLogger logger= gwUtilities.getLogUtils();
        logger.info("In Search Request Processor - process method","");
        SearchRequestDTO searchRequest = exchange.getMessage().getBody(SearchRequestDTO.class);
        Gson gson = new Gson();
        String jsonReq = gson.toJson(searchRequest);
        byte[] reqISO=jsonReq.getBytes("ISO-8859-1");
        String req= new String(reqISO,"UTF-8");
        logger.debug("Object serialised to Json String",req);
        exchange.getIn().setHeader("Ocp-Apim-Subscription-Key",exchange.getIn().getHeader("Ocp-Apim-Subscription-Key"));
        exchange.getIn().setHeader("Authorization",exchange.getIn().getHeader("Token"));
        exchange.getIn().setBody(req);
        exchange.getMessage().removeHeader(Exchange.HTTP_URI);
        logger.info("End of SearchRequestProcessor - process method","");
    }
}

package com.jmi.search.dto;

import java.math.BigDecimal;

public class EngineTypeDTO {

    private Boolean flatten;
    private String intensity;
    private String promptSet ;
    private BigDecimal threshold;
    private BigDecimal timeout;
    private String value;

    public Boolean getFlatten(){
        return flatten;
    }

    public void setFlatten(Boolean flatten){
        this.flatten=flatten;
    }

    public String getIntensity(){
        return intensity;
    }

    public void setIntensity(String intensity){
        this.intensity=intensity;
    }

    public String getPromptSet(){
        return promptSet;
    }

    public void setPromptSet(String promptSet){
        this.promptSet=promptSet;
    }

    public BigDecimal getThreshold(){
        return threshold;
    }

    public void setThreshold(BigDecimal threshold){
        this.threshold=threshold;
    }

    public BigDecimal getTimeout(){
        return timeout;
    }

    public void setTimeout(BigDecimal timeout){
        this.timeout=timeout;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}

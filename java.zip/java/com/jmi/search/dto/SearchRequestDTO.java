package com.jmi.search.dto;

/**
 *  This DTO is used for sending request to Address Verification Service from PC/CC/CM
 */
public class SearchRequestDTO {
    private String country;
    private String search;
    private EngineTypeDTO engine;
    private String layout ;
    private Boolean formattedAddressInPicklist;
    private String localisation;
    private String requestTag ;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country= country;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search){
        this.search=search;
    }

    public Boolean getFormattedAddressInPicklist(){
       return formattedAddressInPicklist;
    }

    public void setFormattedAddressInPicklist(Boolean formattedAddressInPicklist){
        this.formattedAddressInPicklist=formattedAddressInPicklist;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation){
        this.localisation=localisation;
    }

    public String getRequestTag(){
        return requestTag;
    }

    public void setRequestTag(String requestTag){
        this.requestTag=requestTag;
    }

    public EngineTypeDTO getEngine() {
        return engine;
    }

    public void setEngine(EngineTypeDTO engine) {
        this.engine = engine;
    }

    public String getLayout() {
        return layout;
    }

    public void setLayout(String layout) {
        this.layout = layout;
    }
}

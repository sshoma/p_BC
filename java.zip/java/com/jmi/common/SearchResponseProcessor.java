package com.jmi.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jmi.common.dto.AddressSearchResponseDTO;
import gw.api.ig.GwUtilities;
import gw.api.ig.logging.GwLogger;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * This class is used to process the response received from the Address Verification Service
 * Receives the response and transforms into Search Object
 */
public class SearchResponseProcessor implements Processor {
    @Override
    public void process(Exchange exchange) throws Exception {
        GwUtilities gwUtilities = GwUtilities.get(exchange.getContext());
        GwLogger logger = gwUtilities.getLogUtils();
        logger.info("Entering Search Response Processor - process method","");
        String serviceResp=exchange.getIn().getBody(String.class);
        logger.info("Response received from Address Verification Service-Search",serviceResp);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();
        AddressSearchResponseDTO resp=objectMapper.readValue(serviceResp, AddressSearchResponseDTO.class);
        logger.info("Json String converted to Object with status code : ",resp.getStatusCode());
        exchange.getIn().setBody(resp);
        exchange.getIn().setHeader("Content-Type","application/json");
        logger.info("End of Search Response Processor ","");
    }
}


package com.jmi.common.dto;

import java.util.List;

public class PicklistEntryDTO {

    private String moniker ;
    private String partialAddress ;
    private String picklist;
    private String postcode ;
    private Integer score;
    private List<AddressLineDTO> qaAddress ;
    private Boolean fullAddress ;
    private Boolean multiples ;
    private Boolean canStep ;
    private Boolean aliasMatch ;
    private Boolean postcodeRecoded ;
    private Boolean crossBorderMatch;
    private Boolean dummyPOBox;
    private Boolean name ;
    private Boolean information ;
    private Boolean warnInformation ;
    private Boolean incompleteAddr ;
    private Boolean unresolvableRange ;
    private Boolean phantomPrimaryPoint ;
    private Boolean subsidiaryData ;
    private Boolean extendedData;
    private Boolean enhancedData ;

    public String getMoniker() {
        return moniker;
    }

    public void setMoniker(String moniker) {
        this.moniker = moniker;
    }

    public String getPartialAddress() {
        return partialAddress;
    }

    public void setPartialAddress(String partialAddress) {
        this.partialAddress = partialAddress;
    }

    public String getPicklist() {
        return picklist;
    }

    public void setPicklist(String picklist) {
        this.picklist = picklist;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public List<AddressLineDTO> getQaAddress() {
        return qaAddress;
    }

    public void setQaAddress(List<AddressLineDTO> qaAddress) {
        this.qaAddress = qaAddress;
    }

    public Boolean getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(Boolean fullAddress) {
        this.fullAddress = fullAddress;
    }

    public Boolean getMultiples() {
        return multiples;
    }

    public void setMultiples(Boolean multiples) {
        this.multiples = multiples;
    }

    public Boolean getCanStep() {
        return canStep;
    }

    public void setCanStep(Boolean canStep) {
        this.canStep = canStep;
    }

    public Boolean getAliasMatch() {
        return aliasMatch;
    }

    public void setAliasMatch(Boolean aliasMatch) {
        this.aliasMatch = aliasMatch;
    }

    public Boolean getPostcodeRecoded() {
        return postcodeRecoded;
    }

    public void setPostcodeRecoded(Boolean postcodeRecoded) {
        this.postcodeRecoded = postcodeRecoded;
    }

    public Boolean getCrossBorderMatch() {
        return crossBorderMatch;
    }

    public void setCrossBorderMatch(Boolean crossBorderMatch) {
        this.crossBorderMatch = crossBorderMatch;
    }

    public Boolean getDummyPOBox() {
        return dummyPOBox;
    }

    public void setDummyPOBox(Boolean dummyPOBox) {
        this.dummyPOBox = dummyPOBox;
    }

    public Boolean getName() {
        return name;
    }

    public void setName(Boolean name) {
        this.name = name;
    }

    public Boolean getInformation() {
        return information;
    }

    public void setInformation(Boolean information) {
        this.information = information;
    }

    public Boolean getWarnInformation() {
        return warnInformation;
    }

    public void setWarnInformation(Boolean warnInformation) {
        this.warnInformation = warnInformation;
    }

    public Boolean getIncompleteAddr() {
        return incompleteAddr;
    }

    public void setIncompleteAddr(Boolean incompleteAddr) {
        this.incompleteAddr = incompleteAddr;
    }

    public Boolean getUnresolvableRange() {
        return unresolvableRange;
    }

    public void setUnresolvableRange(Boolean unresolvableRange) {
        this.unresolvableRange = unresolvableRange;
    }

    public Boolean getPhantomPrimaryPoint() {
        return phantomPrimaryPoint;
    }

    public void setPhantomPrimaryPoint(Boolean phantomPrimaryPoint) {
        this.phantomPrimaryPoint = phantomPrimaryPoint;
    }

    public Boolean getSubsidiaryData() {
        return subsidiaryData;
    }

    public void setSubsidiaryData(Boolean subsidiaryData) {
        this.subsidiaryData = subsidiaryData;
    }

    public Boolean getExtendedData() {
        return extendedData;
    }

    public void setExtendedData(Boolean extendedData) {
        this.extendedData = extendedData;
    }

    public Boolean getEnhancedData() {
        return enhancedData;
    }

    public void setEnhancedData(Boolean enhancedData) {
        this.enhancedData = enhancedData;
    }
}

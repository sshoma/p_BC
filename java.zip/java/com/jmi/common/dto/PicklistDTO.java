package com.jmi.common.dto;

import java.util.List;

public class PicklistDTO {

    private String fullPicklistMoniker ;
    private List<PicklistEntryDTO> picklistEntry ;
    private String prompt ;
    private Integer total;
    private Boolean autoFormatSafe ;
    private Boolean autoFormatPastClose ;
    private Boolean autoStepinSafe ;
    private Boolean autoStepinPastClose;
    private Boolean largePotential ;
    private Boolean maxMatches ;
    private Boolean moreOtherMatches ;
    private Boolean overThreshold ;
    private Boolean timeout ;

    public String getFullPicklistMoniker(){
        return fullPicklistMoniker;
    }

    public void setFullPicklistMoniker(String fullPicklistMoniker){
        this.fullPicklistMoniker=fullPicklistMoniker;
    }

    public String getPrompt(){
        return prompt;
    }

    public void setPrompt(String prompt){
        this.prompt=prompt;
    }

    public Integer getTotal(){
        return total;
    }

    public void setTotal(Integer total){
        this.total=total;
    }

    public Boolean getAutoFormatSafe(){
        return autoFormatSafe;
    }

    public void setAutoFormatSafe(Boolean autoFormatSafe){
        this.autoFormatSafe=autoFormatSafe;
    }

    public Boolean getAutoFormatPastClose(){
        return autoFormatPastClose;
    }

    public void setAutoFormatPastClose(Boolean autoFormatPastClose){
        this.autoFormatPastClose=autoFormatPastClose;
    }

    public Boolean getAutoStepinSafe(){
        return autoStepinSafe;
    }

    public void setAutoStepinSafe(Boolean autoStepinSafe){
        this.autoStepinSafe=autoStepinSafe;
    }

    public Boolean getAutoStepinPastClose(){
        return autoStepinPastClose;
    }

    public void setAutoStepinPastClose(Boolean autoStepinPastClose){
        this.autoStepinPastClose=autoStepinPastClose;
    }

    public Boolean getLargePotential(){
        return largePotential;
    }

    public void setLargePotential(Boolean largePotential){
        this.largePotential=largePotential;
    }

    public Boolean getMaxMatches(){
        return maxMatches;
    }

    public void setMaxMatches(Boolean maxMatches){
        this.maxMatches=maxMatches;
    }

    public Boolean getMoreOtherMatches(){
        return moreOtherMatches;
    }

    public void setMoreOtherMatches(Boolean moreOtherMatches){
        this.moreOtherMatches=moreOtherMatches;
    }

    public Boolean getOverThreshold(){
        return overThreshold;
    }

    public void setOverThreshold(Boolean overThreshold){
        this.overThreshold=overThreshold;
    }

    public Boolean getTimeout(){
        return timeout;
    }

    public void setTimeout(Boolean timeout){
        this.timeout=timeout;
    }

    public List<PicklistEntryDTO> getPicklistEntry() {
        return picklistEntry;
    }

    public void setPicklistEntry(List<PicklistEntryDTO> picklistEntry) {
        this.picklistEntry = picklistEntry;
    }
}

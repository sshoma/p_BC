package com.jmi.common.dto;

import java.util.List;

public class QAAddressDTO {

    private List<AddressLineDTO> addressLineDTO;
    private Boolean overflow ;
    private Boolean truncated ;
    private int dpvStatus ;
    private Boolean dpvStatusSpecified ;
    private Boolean missingSubPremise  ;

    public List<AddressLineDTO> getAddressLine(){
        return addressLineDTO;
    }
    public void setAddressLine(List<AddressLineDTO> addressLineDTO) {
        this.addressLineDTO = addressLineDTO;
    }

    public Boolean getOverflow() {
        return overflow;
    }

    public void setOverflow(Boolean overflow) {
        this.overflow = overflow;
    }

    public Boolean getTruncated() {
        return truncated;
    }

    public void setTruncated(Boolean truncated) {
        this.truncated = truncated;
    }

    public int getDpvStatus() {
        return dpvStatus;
    }

    public void setDpvStatus(int dpvStatus) {
        this.dpvStatus = dpvStatus;
    }

    public Boolean getDpvStatusSpecified() {
        return dpvStatusSpecified;
    }

    public void setDpvStatusSpecified(Boolean dpvStatusSpecified) {
        this.dpvStatusSpecified = dpvStatusSpecified;
    }

    public Boolean getMissingSubPremise() {
        return missingSubPremise;
    }

    public void setMissingSubPremise(Boolean missingSubPremise) {
        this.missingSubPremise = missingSubPremise;
    }
}

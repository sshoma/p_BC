package com.jmi.common.dto;

import java.util.List;

public class AddressSearchResponseDTO {

    private DataDTO data;
    private String correlationId;
    private List<ErrorDTO> errorDTOS;
    private String statusCode ;

    public DataDTO getData() {
        return data;
    }

    public void setData(DataDTO data){
        this.data = data;
    }

    public String getCorrelationId(){
        return correlationId;
    }

    public void setCorrelationId(String correlationId){
        this.correlationId=correlationId;
    }

    public List<ErrorDTO> getErrors(){
        return errorDTOS;
    }

    public void setErrors( List<ErrorDTO> errorDTOS){
        this.errorDTOS = errorDTOS;
    }

    public String getStatusCode(){
        return statusCode;
    }

    public void setStatusCode(String statusCode){
        this.statusCode=statusCode;
    }
}

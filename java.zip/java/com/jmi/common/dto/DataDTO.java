package com.jmi.common.dto;

public class DataDTO {

    private PicklistDTO qaPicklistDTO;
    private QAAddressDTO qaAddressDTO;
    private VerificationFlagsDTO verificationFlagsDTO;
    private int verifyLevel ;

    public PicklistDTO getQaPicklist(){
        return qaPicklistDTO;
    }

    public void setQaPicklist(PicklistDTO qaPicklistDTO){
        this.qaPicklistDTO = qaPicklistDTO;
    }

    public QAAddressDTO getQaAddress(){
        return qaAddressDTO;
    }

    public void setQaAddress(QAAddressDTO qaAddressDTO){
        this.qaAddressDTO = qaAddressDTO;
    }

    public VerificationFlagsDTO getVerificationFlags(){
        return verificationFlagsDTO;
    }

    public void setVerificationFlags(VerificationFlagsDTO verificationFlagsDTO){
        this.verificationFlagsDTO = verificationFlagsDTO;
    }

    public int getVerifyLevel(){
        return verifyLevel;
    }

    public void setVerifyLevel(int verifyLevel){
        this.verifyLevel=verifyLevel;
    }
}

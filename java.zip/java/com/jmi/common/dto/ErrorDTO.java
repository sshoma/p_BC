package com.jmi.common.dto;

import java.util.List;

public class ErrorDTO {

    private String errorTypeString ;
    private String code;
    private List<String> details ;
    private String errorType ;
    private List<String> messages ;
    private String uid ;

    public String getErrorTypeString(){
        return errorTypeString;
    }

    public void setErrorTypeString(String errorTypeString){
        this.errorTypeString=errorTypeString;
    }

    public String getCode(){
        return code;
    }

    public List<String> details(){
        return details;
    }

    public void setDetails(List<String> details) {
        this.details = details;
    }

    public String getErrorType(){
        return errorType;
    }

    public void setErrorType(String errorType){
        this.errorType=errorType;
    }

    public List<String> getMessages(){
        return messages;
    }

    public void setMessages(List<String> messages) {
        this.messages = messages;
    }

    public String getUid(){
        return uid;
    }

    public void setUid(String uid){
        this.uid=uid;
    }
}



package com.jmi.common.dto;

public class VerificationFlagsDTO {

    private Boolean bldgFirmNameChanged ;
    private Boolean primaryNumberChanged ;
    private Boolean streetCorrected ;
    private Boolean ruralRteHighwayContractMatched ;
    private Boolean cityNameChanged ;
    private Boolean cityAliasMatched ;
    private Boolean stateProvinceChanged ;
    private Boolean postCodeCorrected ;
    private Boolean secondaryNumRetained ;
    private Boolean idenPreStInfoRetained ;
    private Boolean genPreStInfoRetained ;
    private Boolean postStInfoRetained ;

    public Boolean getBldgFirmNameChanged(){
        return bldgFirmNameChanged;
    }

    public void setBldgFirmNameChanged(Boolean bldgFirmNameChanged){
        this.bldgFirmNameChanged=bldgFirmNameChanged;
    }

    public Boolean getPrimaryNumberChanged(){
        return primaryNumberChanged;
    }

    public void setPrimaryNumberChanged(Boolean primaryNumberChanged){
        this.primaryNumberChanged=primaryNumberChanged;
    }

   public Boolean getStreetCorrected(){
        return streetCorrected;
   }

   public void setStreetCorrected(Boolean streetCorrected){
        this.streetCorrected=streetCorrected;
   }

   public Boolean getRuralRteHighwayContractMatched(){
        return ruralRteHighwayContractMatched;
   }

   public void setRuralRteHighwayContractMatched(Boolean ruralRteHighwayContractMatched){
        this.ruralRteHighwayContractMatched=ruralRteHighwayContractMatched;
   }

   public Boolean getCityNameChanged(){
        return cityNameChanged;
   }

   public void setCityNameChanged(Boolean cityNameChanged){
        this.cityNameChanged=cityNameChanged;
   }

   public Boolean getCityAliasMatched(){
        return cityAliasMatched;
   }

   public void setCityAliasMatched(Boolean cityAliasMatched){
        this.cityAliasMatched=cityAliasMatched;
   }

   public Boolean getStateProvinceChanged(){
        return stateProvinceChanged;
   }

   public void setStateProvinceChanged(Boolean stateProvinceChanged){
        this.stateProvinceChanged=stateProvinceChanged;
   }


    public Boolean getPostCodeCorrected() {
        return postCodeCorrected;
    }

    public void setPostCodeCorrected(Boolean postCodeCorrected) {
        this.postCodeCorrected = postCodeCorrected;
    }

    public Boolean getSecondaryNumRetained() {
        return secondaryNumRetained;
    }

    public void setSecondaryNumRetained(Boolean secondaryNumRetained) {
        this.secondaryNumRetained = secondaryNumRetained;
    }

    public Boolean getIdenPreStInfoRetained() {
        return idenPreStInfoRetained;
    }

    public void setIdenPreStInfoRetained(Boolean idenPreStInfoRetained) {
        this.idenPreStInfoRetained = idenPreStInfoRetained;
    }

    public Boolean getGenPreStInfoRetained() {
        return genPreStInfoRetained;
    }

    public void setGenPreStInfoRetained(Boolean genPreStInfoRetained) {
        this.genPreStInfoRetained = genPreStInfoRetained;
    }

    public Boolean getPostStInfoRetained() {
        return postStInfoRetained;
    }

    public void setPostStInfoRetained(Boolean postStInfoRetained) {
        this.postStInfoRetained = postStInfoRetained;
    }
}

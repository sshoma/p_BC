package com.jmi.common.util;

public class CommonUtil {
    public static String SEARCH_ROUTE_DIRECT = "direct:doSearch" ;
    public static String REFINE_ROUTE_DIRECT = "direct:doRefine" ;
    public static String GETADDRESS_ROUTE_DIRECT = "direct:doGetAddress" ;
    public static String SEARCH_ADDRESS_PATH_ID="/searchaddress";
    public static String REFINE_ADDRESS_PATH_ID="/refineaddress";
    public static String GET_ADDRESS_PATH_ID="/getaddress";
    public static String SEARCHADDR_ROUTE_ID="SearchAddress";
    public static String REFINEADDR_ROUTE_ID="RefineAddress";
    public static String GETADDR_ROUTE_ID="GetAddress";

}

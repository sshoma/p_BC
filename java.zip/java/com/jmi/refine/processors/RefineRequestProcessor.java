package com.jmi.refine.processors;

import com.google.gson.Gson;
import com.jmi.refine.dto.RefineRequestDTO;
import gw.api.ig.GwUtilities;
import gw.api.ig.logging.GwLogger;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * This class is used to process Refine request
 * Transforms the RefineRequest object into JsonString
 */
public class RefineRequestProcessor  implements Processor {
    @Override
    public void process(Exchange exchange) throws Exception {
        GwUtilities gwUtilities = GwUtilities.get(exchange.getContext());
        GwLogger logger= gwUtilities.getLogUtils();
        logger.info("Entering Refine Request Processor - process method","");
        RefineRequestDTO refineRequest = exchange.getMessage().getBody(RefineRequestDTO.class);
        Gson gson = new Gson();
        String jsonReq = gson.toJson(refineRequest);
        byte[] reqISO=jsonReq.getBytes("ISO-8859-1");
        String req= new String(reqISO,"UTF-8");
        logger.debug("Object serialised to Json String",req.toString());
        exchange.getIn().setHeader("Ocp-Apim-Subscription-Key",exchange.getIn().getHeader("Ocp-Apim-Subscription-Key"));
        exchange.getIn().setHeader("Authorization",exchange.getIn().getHeader("Token"));
        exchange.getIn().setBody(req);
        exchange.getMessage().removeHeader(Exchange.HTTP_URI);
        logger.info("End of RefineRequestProcessor","");
    }
}

package com.jmi.refine;

import com.jmi.common.dto.AddressSearchResponseDTO;
import com.jmi.refine.dto.RefineRequestDTO;
import com.jmi.refine.processors.RefineRequestProcessor;
import com.jmi.common.util.CommonUtil;
import com.jmi.common.SearchResponseProcessor;
import gw.api.ig.failure.FailureConfiguration;
import gw.impl.ig.failure.DefaultFailureConfiguration;
import gw.impl.ig.route.GwRouteBuilder;
import jakarta.inject.Named;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;

@Named
public class DoRefineRouteBuilder extends GwRouteBuilder {
    @Override
    public void configure() throws Exception {
        rest().path(CommonUtil.REFINE_ADDRESS_PATH_ID)
                .post("/doRefineAddress")
                .description("Refine Address")
                .bindingMode(RestBindingMode.json)
                .consumes("application/json")
                .type(RefineRequestDTO.class)
                .produces("application/json")
                .outType(AddressSearchResponseDTO.class)
                .to(CommonUtil.REFINE_ROUTE_DIRECT);
        from(CommonUtil.REFINE_ROUTE_DIRECT)
                .log("Started Processing Refine Address")
                .routeId(CommonUtil.REFINEADDR_ROUTE_ID)
                .process(new RefineRequestProcessor())
                .marshal()
                .json(JsonLibrary.Jackson, RefineRequestDTO.class)
                .log("Request Post Marshalling")
                .to("{{INTEGRATION.ENDPOINT.REMOTEHOST}}"+"{{INTEGRATION.ENDPOINT.REMOTEURI}}"+"{{INTEGRATION.ENDPOINT.REFINEURL}}")
                .log("Endpoint URL"+"{{INTEGRATION.ENDPOINT.REMOTEHOST}}"+"{{INTEGRATION.ENDPOINT.REMOTEURI}}"+"{{INTEGRATION.ENDPOINT.REFINEURL}}")
                .process(new SearchResponseProcessor())
                .log("END")
                .end();
    }

    @Override
    public FailureConfiguration<?> createFailureConfiguration() {
        return new DefaultFailureConfiguration();
    }
}

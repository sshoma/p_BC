package com.jmi.refine.dto;

import java.math.BigDecimal;

/**
 * This class is used to send the refine request object to the DoRefine Endpoint
 */
public class RefineRequestDTO {

    private String moniker;
    private String refinement ;
    private String layout ;
    private Boolean formattedAddressInPicklist ;
    private BigDecimal threshold ;
    private BigDecimal timeout;
    private String localisation ;
    private String requestTag;

    public String getMoniker() {
        return moniker;
    }

    public void setMoniker(String moniker) {
        this.moniker = moniker;
    }

    public String getRefinement() {
        return refinement;
    }

    public void setRefinement(String refinement) {
        this.refinement = refinement;
    }

    public String getLayout() {
        return layout;
    }

    public void setLayout(String layout) {
        this.layout = layout;
    }

    public Boolean getFormattedAddressInPicklist() {
        return formattedAddressInPicklist;
    }

    public void setFormattedAddressInPicklist(Boolean formattedAddressInPicklist) {
        this.formattedAddressInPicklist = formattedAddressInPicklist;
    }

    public BigDecimal getThreshold() {
        return threshold;
    }

    public void setThreshold(BigDecimal threshold) {
        this.threshold = threshold;
    }

    public BigDecimal getTimeout() {
        return timeout;
    }

    public void setTimeout(BigDecimal timeout) {
        this.timeout = timeout;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    public String getRequestTag() {
        return requestTag;
    }

    public void setRequestTag(String requestTag) {
        this.requestTag = requestTag;
    }
}

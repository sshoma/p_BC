package com.jmi.getaddress;

import com.jmi.getaddress.dto.AddressRequestDTO;
import com.jmi.getaddress.processors.GetAddressRequestProcessor;
import com.jmi.common.dto.AddressSearchResponseDTO;
import com.jmi.common.util.CommonUtil;
import com.jmi.common.SearchResponseProcessor;
import gw.api.ig.failure.FailureConfiguration;
import gw.impl.ig.failure.DefaultFailureConfiguration;
import gw.impl.ig.route.GwRouteBuilder;
import jakarta.inject.Named;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;

@Named
public class GetAddressRouteBuilder extends GwRouteBuilder {
    @Override
    public void configure() throws Exception {
        rest().path(CommonUtil.GET_ADDRESS_PATH_ID)
                .post("/doGetAddress")
                .description("Get Address")
                .bindingMode(RestBindingMode.json)
                .consumes("application/json")
                .type(AddressRequestDTO.class)
                .produces("application/json")
                .outType(AddressSearchResponseDTO.class)
                .to(CommonUtil.GETADDRESS_ROUTE_DIRECT);
        from(CommonUtil.GETADDRESS_ROUTE_DIRECT)
                .routeId(CommonUtil.GETADDR_ROUTE_ID)
                .log("Started Processing for Get Address")
                .process(new GetAddressRequestProcessor())
                .marshal()
                .json(JsonLibrary.Jackson, AddressRequestDTO.class)
                .log("Request Post Marshalling")
                .to("{{INTEGRATION.ENDPOINT.REMOTEHOST}}"+"{{INTEGRATION.ENDPOINT.REMOTEURI}}"+"{{INTEGRATION.ENDPOINT.GETADDRESSURL}}")
                .log("ENDPOINT"+"{{INTEGRATION.ENDPOINT.REMOTEHOST}}"+"{{INTEGRATION.ENDPOINT.REMOTEURI}}"+"{{INTEGRATION.ENDPOINT.GETADDRESSURL}}")
                .process(new SearchResponseProcessor())
                .log("End")
                .end();
    }

    @Override
    public FailureConfiguration<?> createFailureConfiguration() {
        return new DefaultFailureConfiguration();
    }
}

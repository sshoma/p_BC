package com.jmi.getaddress.dto;

/**
 * This class is used to send the request object to the GetAddress Endpoint
 */
public class AddressRequestDTO {
    private String layout ;
    private String moniker;
    private String localisation;
    private String requestTag ;

    public String getLayout() {
        return layout;
    }

    public void setLayout(String layout) {
        this.layout = layout;
    }

    public String getMoniker() {
        return moniker;
    }

    public void setMoniker(String moniker) {
        this.moniker = moniker;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    public String getRequestTag() {
        return requestTag;
    }

    public void setRequestTag(String requestTag) {
        this.requestTag = requestTag;
    }
}

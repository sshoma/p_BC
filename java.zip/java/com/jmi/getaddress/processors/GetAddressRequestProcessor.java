package com.jmi.getaddress.processors;

import com.google.gson.Gson;
import com.jmi.getaddress.dto.AddressRequestDTO;
import gw.api.ig.GwUtilities;
import gw.api.ig.logging.GwLogger;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * To process Address Request
 * Transforms the GetAddress Request object into JsonString
 */
public class GetAddressRequestProcessor implements Processor {
    @Override
    public void process(Exchange exchange) throws Exception {
        GwUtilities gwUtilities = GwUtilities.get(exchange.getContext());
        GwLogger logger= gwUtilities.getLogUtils();
        logger.info("Entering Get Address Processor - process method","");
        AddressRequestDTO addressRequest = exchange.getMessage().getBody(AddressRequestDTO.class);
        Gson gson = new Gson();
        String jsonReq = gson.toJson(addressRequest);
        byte[] reqISO=jsonReq.getBytes("ISO-8859-1");
        String req= new String(reqISO,"UTF-8");
        logger.info("Address Request: " + req,"");
        exchange.getIn().setHeader("Ocp-Apim-Subscription-Key",exchange.getIn().getHeader("Ocp-Apim-Subscription-Key"));
        exchange.getIn().setHeader("Authorization",exchange.getIn().getHeader("Token"));
        exchange.getIn().setBody(req);
        exchange.getMessage().removeHeader(Exchange.HTTP_URI);
        logger.info("End of RefineRequestProcessor - process method","");
    }
}

/**
 * Camel routes should be defined under com.guidewire. Custom packages can be created but they need to be under this main
 * package otherwise routes will not be picked up during startup.
 */
package com.guidewire.integrationgateway;